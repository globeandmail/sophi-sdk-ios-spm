//
//  PoplinSDK.h
//  PoplinSDK
//
//  Created by Carlos Hernández on 6/9/21.
//

#import <Foundation/Foundation.h>

//! Project version number for PoplinSDK.
FOUNDATION_EXPORT double PoplinSDKVersionNumber;

//! Project version string for PoplinSDK.
FOUNDATION_EXPORT const unsigned char PoplinSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PoplinSDK/PublicHeader.h>


